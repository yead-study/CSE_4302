#include "cube.h"

cube::cube()
{
    //ctor
}

cube::~cube()
{
    //dtor
}
