#include "threedimensionalshape.h"

threedimensionalshape::threedimensionalshape()
{
    //ctor
}

threedimensionalshape::~threedimensionalshape()
{
    //dtor
}
