#include "cylinder.h"

cylinder::cylinder()
{
    //ctor
}

cylinder::~cylinder()
{
    //dtor
}
