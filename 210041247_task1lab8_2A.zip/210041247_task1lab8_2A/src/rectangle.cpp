#include "rectangle.h"

rectangle::rectangle()
{
    //ctor
}

rectangle::~rectangle()
{
    //dtor
}
