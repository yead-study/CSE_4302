#include "twodimensionalshape.h"

twodimensionalshape::twodimensionalshape()
{
    //ctor
}

twodimensionalshape::~twodimensionalshape()
{
    //dtor
}
