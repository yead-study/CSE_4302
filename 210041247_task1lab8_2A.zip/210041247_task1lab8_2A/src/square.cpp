#include "square.h"

square::square()
{
    //ctor
}

square::~square()
{
    //dtor
}
