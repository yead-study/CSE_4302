#include "sphere.h"

sphere::sphere()
{
    //ctor
}

sphere::~sphere()
{
    //dtor
}
