#include "triangle.h"

triangle::triangle()
{
    //ctor
}

triangle::~triangle()
{
    //dtor
}
