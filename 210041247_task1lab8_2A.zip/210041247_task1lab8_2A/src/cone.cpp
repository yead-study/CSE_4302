#include "cone.h"

cone::cone()
{
    //ctor
}

cone::~cone()
{
    //dtor
}
