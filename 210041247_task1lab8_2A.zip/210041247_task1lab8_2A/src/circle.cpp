#include "circle.h"

circle::circle()
{
    //ctor
}

circle::~circle()
{
    //dtor
}
