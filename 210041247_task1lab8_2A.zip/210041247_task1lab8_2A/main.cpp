#include <iostream>

using namespace std;
#include"circle.h"
#include"cone.h"
#include"cube.h"
#include"cylinder.h"
#include"rectangle.h"
#include"shape.h"
#include"sphere.h"
#include"square.h"
#include"threedimensionalshape.h"
#include"triangle.h"
#include"twodimensionalshape.h"

int main()
{
    circle cir(10);
    cone con(10,100);
    cube cub(10);
    cylinder cy(10,10);
    rectangle rec(10,5);
    sphere sp(10);
    square sq(10);
    triangle tr(10,10,10);
    cir.whoami();
    cout <<  "Circle: Area:" << cir.area()<< " perimeter:" << cir.perimeter() << endl;
    con.whoami();
    cout <<  "Cone: Area:" << con.area()<< " volume:" << con.volume() << endl;
    cub.whoami();
    cout <<  "Cube: Area:" << cub.area()<< " volume:" << cub.volume() << endl;
    cy.whoami();
    cout <<  "Cylinder: Area:" << cy.area()<< " volume:" << cy.volume() << endl;
    rec.whoami();
    cout <<  "rectangle: Area:" << rec.area()<< " perimeter:" << rec.perimeter() << endl;
    cir.whoami();
    cout <<  "sphere: Area:" << cir.area()<< " volume:" << cir.perimeter() << endl;
    sq.whoami();
    cout <<  "Square: Area:" << sq.area()<< " perimeter:" << sq.perimeter() << endl;
    tr.whoami();
    cout <<  "triangle: Area:" << tr.area()<< " perimeter:" << tr.perimeter() << endl;

    return 0;
}
