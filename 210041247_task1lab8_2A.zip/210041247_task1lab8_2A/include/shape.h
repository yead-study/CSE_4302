#ifndef SHAPE_H
#define SHAPE_H


class shape
{
    public:
        shape();
        virtual ~shape();

    protected:

    private:
};

#endif // SHAPE_H
