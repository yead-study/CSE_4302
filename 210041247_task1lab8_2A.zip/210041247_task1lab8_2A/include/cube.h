#ifndef CUBE_H
#define CUBE_H

#include <threedimensionalshape.h>
#include<iostream>
using namespace std;

class cube : public threedimensionalshape
{
    public:
        cube();
        cube(float _radius): radius(_radius)
        {
            volume();
            area();
        }
        virtual ~cube();

        float Getradius() { return radius; }
        void Setradius(float val) { radius = val; }
        void whoami()
        {
            cout << "I am cube." << endl;
            threedimensionalshape::whoami();
        }
        float area()
        {
            float _area = 6*radius*radius;
            Setarea(_area);
            return _area;
        }
        float volume()
        {
            float _volume = radius*radius*radius;
            Setvolume(_volume);
            return _volume;
        }
    protected:

    private:
        float radius;
};

#endif // CUBE_H
