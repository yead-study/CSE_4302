#ifndef SPHERE_H
#define SPHERE_H

#include <threedimensionalshape.h>
#include<iostream>
using namespace std;

class sphere : public threedimensionalshape
{
    public:
        sphere();
        sphere(float _radius): radius(_radius)
        {
            area();
            volume();
        }
        virtual ~sphere();

        float Getradius() { return radius; }
        void Setradius(float val) { radius = val; }
        void whoami()
        {
            cout << "I am sphere. "<< endl;
            threedimensionalshape::whoami();
        }
        float area()
        {
            float _area = 4*3.1416*radius*radius;
            Setarea(_area);
            return _area;
        }
        float volume()
        {
            float _volume = (4/3)*3.1416*radius*radius*radius;
            Setvolume(_volume);
            return _volume;
        }
    protected:

    private:
        float radius;
};

#endif // SPHERE_H
