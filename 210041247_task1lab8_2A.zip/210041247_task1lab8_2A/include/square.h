#ifndef SQUARE_H
#define SQUARE_H

#include <twodimensionalshape.h>


class square : public twodimensionalshape
{
    public:
        square();

        square(float _length):length(_length)
        {}
        virtual ~square();

        float Getlength() { return length; }
        void Setlength(float val) { length = val; }
        void whoami()
        {
            cout << "I am Square." << endl;
            twodimensionalshape::whoami();
        }
        float area()
        {
            float _area = length*length;
            Setarea(_area);
            return _area;
        }
        float perimeter()
        {
            float _perimeter = 4*length;
            Setperimeter(length);
            return length;
        }
    protected:

    private:
        float length;
};

#endif // SQUARE_H
