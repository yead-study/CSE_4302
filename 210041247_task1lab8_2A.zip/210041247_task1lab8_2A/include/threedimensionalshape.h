#ifndef THREEDIMENSIONALSHAPE_H
#define THREEDIMENSIONALSHAPE_H

#include <shape.h>
#include<iostream>
using namespace  std;

class threedimensionalshape : public shape
{
    public:
        threedimensionalshape();
        virtual ~threedimensionalshape();

        float Getarea() { return area; }
        void Setarea(float val) { area = val; }
        float Getvolume() { return volume; }
        void Setvolume(float val) { volume = val; }
        static void whoami()
        {
            cout << "I am a three dimensional shape" << endl;
        }
    protected:

    private:
        float area;
        float volume;
};

#endif // THREEDIMENSIONALSHAPE_H
