#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <twodimensionalshape.h>
#include<math.h>

class triangle : public twodimensionalshape
{
    public:
        triangle();
        triangle(float _a,float _b, float _c): a(_a),b(_b),c(_c)
        {
            perimeter();
            area();
        }
        virtual ~triangle();

        float Geta() { return a; }
        void Seta(float val) { a = val; }
        float Getb() { return b; }
        void Setb(float val) { b = val; }
        float Getc() { return c; }
        void Setc(float val) { c = val; }
        void whoami()
        {
            cout << "I am Triangle." << endl;
            twodimensionalshape::whoami();
        }
        float  perimeter()
        {
            float _perimeter = a+b+c;
            Setperimeter(_perimeter);
            return _perimeter;
        }
        float area()
        {
            float peri = perimeter()/2;
            float _area = sqrt(peri*(peri-a)*(peri-b)*(peri-c));
            Setarea(_area);
            return _area;
        }
    protected:

    private:
        float a;
        float b;
        float c;
};

#endif // TRIANGLE_H
