#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <threedimensionalshape.h>
#include<iostream>
using namespace std;

class rectangle : public threedimensionalshape
{
    public:
        rectangle();
        rectangle(float _length, float _breadth): length(_length),breadth(_breadth)
        {
            area();
            perimeter();
        }
        virtual ~rectangle();
        void whoami()
        {
            cout << "I am Rectangle." << endl;
            threedimensionalshape::whoami();
        }
        float area()
        {
            float _area = length*breadth;
            Setarea(_area);
            return _area;
        }
        float perimeter()
        {
            float _volume = 2*(length+ breadth);
            Setvolume(_volume);
            return _volume;
        }
    protected:

    private:
        float length;
        float breadth;
};

#endif // RECTANGLE_H
