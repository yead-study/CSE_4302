#ifndef CONE_H
#define CONE_H

#include <threedimensionalshape.h>
#include<math.h>
#include<iostream>
using namespace std;

class cone : public threedimensionalshape
{
    public:
        cone();
        cone(float _radius,float _height) : radius(_radius),height(_height)
        {
            area();
        }
        virtual ~cone();

        float Getradius() { return radius; }
        void Setradius(float val) { radius = val; }
        float getheight(){ return height;}
        float setheight(float _height){height = _height;}
        void whoami()
        {
            cout << "I am cone." << endl;
            threedimensionalshape::whoami();
        }
        float area()
        {
            float _area = 3.1416*radius*radius + sqrt(radius*radius+height*height);
            Setarea(_area);
            return _area;
        }
        float volume()
        {
            float _volume = 0.3333*3.1416*radius*radius*height;
            Setvolume(_volume);
            return _volume;
        }
    protected:

    private:
        float radius;
        float height;
};

#endif // CONE_H
