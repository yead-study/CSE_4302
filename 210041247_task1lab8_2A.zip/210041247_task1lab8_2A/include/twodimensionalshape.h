#ifndef TWODIMENSIONALSHAPE_H
#define TWODIMENSIONALSHAPE_H

#include <shape.h>
#include<iostream>
using namespace std;

class twodimensionalshape : public shape
{
    public:
        twodimensionalshape();
        virtual ~twodimensionalshape();

        float Getarea() { return area; }
        void Setarea(float val) { area = val; }
        float Getperimeter() { return perimeter; }
        void Setperimeter(float val) { perimeter = val; }
        static void whoami()
        {
            cout<< "I am a two-dimensional shape"<<endl;
        }
    protected:

    private:
        float area;
        float perimeter;
};

#endif // TWODIMENSIONALSHAPE_H
