#ifndef CYLINDER_H
#define CYLINDER_H

#include <threedimensionalshape.h>
#include<iostream>
using namespace std;

class cylinder : public threedimensionalshape
{
    public:
        cylinder();
        cylinder(float _radius, float _height):radius(_radius),height(_height)
        {
            volume();
            area();
        }
        virtual ~cylinder();

        float Getradius() { return radius; }
        void Setradius(float val) { radius = val; }
        float Getheight() { return height; }
        void Setheight(float val) { height = val; }
        void whoami()
        {
            cout << "I am cylinder." << endl;
            threedimensionalshape::whoami();
        }
        float area()
        {
            float _area = 2*3.1416*radius*height + 2*3.1416*radius*radius;
            Setarea(_area);
            return _area;
        }
        float volume()
        {
            float _volume = 3.1416*radius*radius*height;
            Setvolume(_volume);
            return _volume;
        }
    protected:

    private:
        float radius;
        float height;
};

#endif // CYLINDER_H
