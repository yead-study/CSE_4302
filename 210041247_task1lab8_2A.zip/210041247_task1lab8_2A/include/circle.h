#ifndef CIRCLE_H
#define CIRCLE_H

#include <twodimensionalshape.h>


class circle : public twodimensionalshape
{
    public:
        circle();
        circle(float _radius):radius(_radius)
        {
            area();
            perimeter();
        }
        virtual ~circle();

        float Getradius() { return radius; }
        void Setradius(float val) { radius = val; }
        float area()
        {
            float _area = 3.1416*radius*radius;
            Setarea(_area);
            return _area;
        }
        float perimeter()
        {
            float _perimeter = 2*3.1416*radius;
            Setperimeter(_perimeter);
            return _perimeter;
        }
        void whoami()
        {
            cout << "I am Circle." << endl;
            twodimensionalshape::whoami();
        }
    protected:

    private:
        float radius;
};

#endif // CIRCLE_H
